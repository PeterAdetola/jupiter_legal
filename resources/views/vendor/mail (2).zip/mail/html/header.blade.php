@props(['url'])
<tr>
<td class="header">
<a href="{{ $url }}" style="display: inline-block;">
    <img src="{{ url('img/logo-ii.png') }}" width="131" height="62" alt="Jupiter Legal Logo">

</a>
</td>
</tr>
