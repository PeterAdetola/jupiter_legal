/*
Name: 			Barber
Written by: 	Okler Themes - (http://www.okler.net)
Theme Version:	12.1.0
*/