/*
Name:           Demo Beauty Salon
Written by:     Okler Themes - (http://www.okler.net)
Theme Version:  12.1.0
*/
