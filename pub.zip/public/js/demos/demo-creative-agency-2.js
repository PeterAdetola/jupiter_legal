/*
Name:           Demo Creative Agency 2
Written by:     Okler Themes - (http://www.okler.net)
Theme Version:  12.1.0
*/

(($ => {
    $(window).on('load', () => {
		setTimeout(() => {
			$('.custom-hero-bg').addClass('loaded');
		}, 500);
	
	});
})).apply( this, [ jQuery ]);
